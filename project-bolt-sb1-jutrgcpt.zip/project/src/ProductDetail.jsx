import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Plus, Minus, ShoppingCart } from 'lucide-react';
import { getProductById } from './data';

const ProductDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [product, setProduct] = useState(null);
  const [selectedOptions, setSelectedOptions] = useState({});
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    const foundProduct = getProductById(id);
    if (foundProduct) {
      setProduct(foundProduct);
      // Initialiser les options sélectionnées
      const initialOptions = {};
      foundProduct.options?.forEach((optionGroup, groupIndex) => {
        if (optionGroup.type === 'checkbox') {
          initialOptions[groupIndex] = {};
        } else if (optionGroup.type === 'radio' || optionGroup.type === 'select') {
          initialOptions[groupIndex] = null;
        }
      });
      setSelectedOptions(initialOptions);
    }
  }, [id]);

  const handleCheckboxChange = (groupIndex, choiceIndex, increment = true) => {
    setSelectedOptions(prev => {
      const newOptions = { ...prev };
      const currentGroup = newOptions[groupIndex] || {};
      const currentCount = currentGroup[choiceIndex] || 0;
      const optionGroup = product.options[groupIndex];
      
      if (increment) {
        // Vérifier la limite max
        const totalSelected = Object.values(currentGroup).reduce((sum, count) => sum + count, 0);
        if (totalSelected < optionGroup.max) {
          currentGroup[choiceIndex] = currentCount + 1;
        }
      } else {
        if (currentCount > 0) {
          currentGroup[choiceIndex] = currentCount - 1;
          if (currentGroup[choiceIndex] === 0) {
            delete currentGroup[choiceIndex];
          }
        }
      }
      
      newOptions[groupIndex] = currentGroup;
      return newOptions;
    });
  };

  const handleRadioChange = (groupIndex, choiceIndex) => {
    setSelectedOptions(prev => ({
      ...prev,
      [groupIndex]: choiceIndex
    }));
  };

  const handleSelectChange = (groupIndex, choiceIndex) => {
    setSelectedOptions(prev => ({
      ...prev,
      [groupIndex]: choiceIndex
    }));
  };

  const calculateTotal = () => {
    if (!product) return 0;
    
    let total = product.price;
    
    product.options?.forEach((optionGroup, groupIndex) => {
      const selectedGroup = selectedOptions[groupIndex];
      
      if (optionGroup.type === 'checkbox' && selectedGroup) {
        Object.entries(selectedGroup).forEach(([choiceIndex, count]) => {
          const choice = optionGroup.choices[parseInt(choiceIndex)];
          total += choice.price * count;
        });
      } else if ((optionGroup.type === 'radio' || optionGroup.type === 'select') && selectedGroup !== null) {
        const choice = optionGroup.choices[selectedGroup];
        total += choice.price;
      }
    });
    
    return total * quantity;
  };

  const addToCart = () => {
    const cartItem = {
      product,
      selectedOptions,
      quantity,
      total: calculateTotal()
    };
    
    console.log('Ajout au panier:', cartItem);
    // Ici vous pouvez faire l'appel API ou stocker dans le state global
    alert(`${product.name} ajouté au panier !`);
  };

  const getTotalSelectedInGroup = (groupIndex) => {
    const selectedGroup = selectedOptions[groupIndex] || {};
    return Object.values(selectedGroup).reduce((sum, count) => sum + count, 0);
  };

  if (!product) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">Produit non trouvé</h2>
          <button
            onClick={() => navigate('/')}
            className="bg-orange-500 text-white px-6 py-2 rounded-lg hover:bg-orange-600 transition-colors"
          >
            Retour à l'accueil
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center">
          <button
            onClick={() => navigate('/')}
            className="mr-4 p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <ArrowLeft className="h-6 w-6 text-gray-600" />
          </button>
          <h1 className="text-lg font-semibold text-gray-800">{product.name}</h1>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-6">
        {/* Image et infos produit */}
        <div className="bg-white rounded-xl shadow-sm overflow-hidden mb-6">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-64 object-cover"
          />
          <div className="p-6">
            <h2 className="text-2xl font-bold text-gray-800 mb-2">{product.name}</h2>
            <p className="text-gray-600 mb-4">{product.description}</p>
            <div className="text-2xl font-bold text-orange-500">
              {product.price.toFixed(2)} €
            </div>
          </div>
        </div>

        {/* Options */}
        {product.options && product.options.length > 0 && (
          <div className="space-y-6 mb-6">
            {product.options.map((optionGroup, groupIndex) => (
              <div key={groupIndex} className="bg-white rounded-xl shadow-sm p-6">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-semibold text-gray-800">
                    {optionGroup.name}
                  </h3>
                  {optionGroup.type === 'checkbox' && (
                    <span className="text-sm text-gray-500">
                      {getTotalSelectedInGroup(groupIndex)}/{optionGroup.max}
                    </span>
                  )}
                </div>

                <div className="space-y-3">
                  {optionGroup.choices.map((choice, choiceIndex) => (
                    <div key={choiceIndex} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:border-orange-300 transition-colors">
                      <div className="flex items-center space-x-3">
                        {choice.image && (
                          <img
                            src={choice.image}
                            alt={choice.label}
                            className="w-12 h-12 object-cover rounded-lg"
                          />
                        )}
                        <div>
                          <div className="font-medium text-gray-800">{choice.label}</div>
                          {choice.price > 0 && (
                            <div className="text-sm text-orange-500">+{choice.price.toFixed(2)} €</div>
                          )}
                        </div>
                      </div>

                      {/* Contrôles selon le type */}
                      {optionGroup.type === 'checkbox' && (
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => handleCheckboxChange(groupIndex, choiceIndex, false)}
                            className="w-8 h-8 rounded-full border-2 border-gray-300 flex items-center justify-center hover:border-orange-500 transition-colors"
                            disabled={!selectedOptions[groupIndex]?.[choiceIndex]}
                          >
                            <Minus className="h-4 w-4 text-gray-600" />
                          </button>
                          <span className="w-8 text-center font-medium">
                            {selectedOptions[groupIndex]?.[choiceIndex] || 0}
                          </span>
                          <button
                            onClick={() => handleCheckboxChange(groupIndex, choiceIndex, true)}
                            className="w-8 h-8 rounded-full border-2 border-gray-300 flex items-center justify-center hover:border-orange-500 transition-colors"
                            disabled={getTotalSelectedInGroup(groupIndex) >= optionGroup.max}
                          >
                            <Plus className="h-4 w-4 text-gray-600" />
                          </button>
                        </div>
                      )}

                      {optionGroup.type === 'radio' && (
                        <input
                          type="radio"
                          name={`radio-${groupIndex}`}
                          checked={selectedOptions[groupIndex] === choiceIndex}
                          onChange={() => handleRadioChange(groupIndex, choiceIndex)}
                          className="w-5 h-5 text-orange-500 focus:ring-orange-500"
                        />
                      )}

                      {optionGroup.type === 'select' && groupIndex === 0 && (
                        <input
                          type="radio"
                          name={`select-${groupIndex}`}
                          checked={selectedOptions[groupIndex] === choiceIndex}
                          onChange={() => handleSelectChange(groupIndex, choiceIndex)}
                          className="w-5 h-5 text-orange-500 focus:ring-orange-500"
                        />
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Quantité et ajout au panier */}
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-4">
              <span className="text-lg font-medium text-gray-800">Quantité :</span>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-10 h-10 rounded-full border-2 border-gray-300 flex items-center justify-center hover:border-orange-500 transition-colors"
                >
                  <Minus className="h-5 w-5 text-gray-600" />
                </button>
                <span className="w-12 text-center text-lg font-medium">{quantity}</span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-10 h-10 rounded-full border-2 border-gray-300 flex items-center justify-center hover:border-orange-500 transition-colors"
                >
                  <Plus className="h-5 w-5 text-gray-600" />
                </button>
              </div>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-gray-800">
                {calculateTotal().toFixed(2)} €
              </div>
              <div className="text-sm text-gray-500">Total</div>
            </div>
          </div>

          <button
            onClick={addToCart}
            className="w-full bg-orange-500 text-white py-4 rounded-xl font-semibold text-lg flex items-center justify-center space-x-2 hover:bg-orange-600 transition-colors"
          >
            <ShoppingCart className="h-6 w-6" />
            <span>Ajouter au panier</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;