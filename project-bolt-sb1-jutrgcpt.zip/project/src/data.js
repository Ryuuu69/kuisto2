export const products = [
  {
    id: 1,
    name: "Big Cheese",
    description: "Notre burger signature avec double steak, fromage cheddar, bacon croustillant, salade et sauce maison",
    price: 12.90,
    image: "https://images.pexels.com/photos/1639562/pexels-photo-1639562.jpeg?auto=compress&cs=tinysrgb&w=500",
    category: "Burgers",
    options: [
      {
        name: "Suppléments",
        type: "checkbox",
        max: 3,
        choices: [
          {
            label: "Bacon supplémentaire",
            price: 2.50,
            image: "https://images.pexels.com/photos/248444/pexels-photo-248444.jpeg?auto=compress&cs=tinysrgb&w=200"
          },
          {
            label: "Fromage supplémentaire",
            price: 1.50,
            image: "https://images.pexels.com/photos/773253/pexels-photo-773253.jpeg?auto=compress&cs=tinysrgb&w=200"
          },
          {
            label: "Avocat",
            price: 2.00,
            image: "https://images.pexels.com/photos/557659/pexels-photo-557659.jpeg?auto=compress&cs=tinysrgb&w=200"
          },
          {
            label: "Oignons frits",
            price: 1.00,
            image: "https://images.pexels.com/photos/144248/potatoes-french-mourning-funny-144248.jpeg?auto=compress&cs=tinysrgb&w=200"
          }
        ]
      },
      {
        name: "Retirer quelque chose",
        type: "checkbox",
        max: 5,
        choices: [
          {
            label: "Sans salade",
            price: 0,
            image: null
          },
          {
            label: "Sans tomate",
            price: 0,
            image: null
          },
          {
            label: "Sans oignons",
            price: 0,
            image: null
          },
          {
            label: "Sans cornichons",
            price: 0,
            image: null
          }
        ]
      },
      {
        name: "Boisson",
        type: "radio",
        max: 1,
        choices: [
          {
            label: "Coca-Cola 33cl",
            price: 2.50,
            image: "https://images.pexels.com/photos/50593/coca-cola-cold-drink-soft-drink-coke-50593.jpeg?auto=compress&cs=tinysrgb&w=200"
          },
          {
            label: "Sprite 33cl",
            price: 2.50,
            image: "https://images.pexels.com/photos/1292294/pexels-photo-1292294.jpeg?auto=compress&cs=tinysrgb&w=200"
          },
          {
            label: "Eau plate 50cl",
            price: 1.50,
            image: "https://images.pexels.com/photos/416528/pexels-photo-416528.jpeg?auto=compress&cs=tinysrgb&w=200"
          },
          {
            label: "Pas de boisson",
            price: 0,
            image: null
          }
        ]
      },
      {
        name: "Accompagnement",
        type: "select",
        max: 1,
        choices: [
          {
            label: "Frites maison",
            price: 0,
            image: "https://images.pexels.com/photos/1893556/pexels-photo-1893556.jpeg?auto=compress&cs=tinysrgb&w=200"
          },
          {
            label: "Potatoes épicées",
            price: 1.00,
            image: "https://images.pexels.com/photos/162971/potatoes-french-mourning-funny-162971.jpeg?auto=compress&cs=tinysrgb&w=200"
          },
          {
            label: "Salade verte",
            price: 0.50,
            image: "https://images.pexels.com/photos/257816/pexels-photo-257816.jpeg?auto=compress&cs=tinysrgb&w=200"
          },
          {
            label: "Onion rings",
            price: 2.00,
            image: "https://images.pexels.com/photos/2233348/pexels-photo-2233348.jpeg?auto=compress&cs=tinysrgb&w=200"
          }
        ]
      }
    ]
  },
  {
    id: 2,
    name: "Chicken Deluxe",
    description: "Filet de poulet grillé, fromage suisse, avocat, salade et sauce ranch",
    price: 11.50,
    image: "https://images.pexels.com/photos/2282532/pexels-photo-2282532.jpeg?auto=compress&cs=tinysrgb&w=500",
    category: "Burgers",
    options: [
      {
        name: "Suppléments",
        type: "checkbox",
        max: 2,
        choices: [
          {
            label: "Bacon",
            price: 2.50,
            image: "https://images.pexels.com/photos/248444/pexels-photo-248444.jpeg?auto=compress&cs=tinysrgb&w=200"
          },
          {
            label: "Fromage cheddar",
            price: 1.50,
            image: "https://images.pexels.com/photos/773253/pexels-photo-773253.jpeg?auto=compress&cs=tinysrgb&w=200"
          }
        ]
      }
    ]
  },
  {
    id: 3,
    name: "Veggie Burger",
    description: "Steak végétarien, légumes grillés, avocat et sauce végane",
    price: 10.90,
    image: "https://images.pexels.com/photos/1199958/pexels-photo-1199958.jpeg?auto=compress&cs=tinysrgb&w=500",
    category: "Burgers",
    options: []
  }
];

export const getProductById = (id) => {
  return products.find(product => product.id === parseInt(id));
};