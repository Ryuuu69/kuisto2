/// vite.config.js
import { defineConfig } from 'vite'

export default defineConfig({
  publicDir: 'images'    // maintenant Vite servira ton dossier images comme dossier public
})
